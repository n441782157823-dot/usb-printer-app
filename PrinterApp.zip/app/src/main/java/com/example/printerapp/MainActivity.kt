package com.example.printerapp

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.printerapp.databinding.ActivityMainBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var selectedFileUri: Uri? = null
    private var selectedFileName: String = ""
    private lateinit var printerService: PrinterService

    // File picker launcher
    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            selectedFileUri = it
            selectedFileName = getFileName(it)
            updateFileInfo()
        }
    }

    // Permissions launcher
    private val permissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.values.all { it }
        if (allGranted) {
            openFilePicker()
        } else {
            Toast.makeText(this, "نیاز است مجوزهای مورد نیاز را قبول کنید", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        printerService = PrinterService(this)

        // UI Setup
        setupUI()

        // Check and request permissions
        checkPermissions()
    }

    private fun setupUI() {
        binding.apply {
            // Select File Button
            btnSelectFile.setOnClickListener {
                if (hasPermissions()) {
                    openFilePicker()
                } else {
                    requestPermissions()
                }
            }

            // Print Button
            btnPrint.setOnClickListener {
                if (selectedFileUri != null) {
                    performPrint()
                } else {
                    Toast.makeText(
                        this@MainActivity,
                        "لطفا ابتدا فایلی را انتخاب کنید",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            // Clear Button
            btnClear.setOnClickListener {
                clearSelection()
            }
        }
    }

    private fun openFilePicker() {
        val mimeTypes = arrayOf(
            "image/*",
            "application/pdf",
            "application/msword",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "text/plain"
        )
        filePickerLauncher.launch(mimeTypes)
    }

    private fun performPrint() {
        binding.progressBar.visibility = android.widget.ProgressBar.VISIBLE
        binding.btnPrint.isEnabled = false

        CoroutineScope(Dispatchers.Main).launch {
            try {
                if (printerService.isPrinterConnected()) {
                    val success = printerService.printFile(selectedFileUri!!, selectedFileName)
                    if (success) {
                        Toast.makeText(
                            this@MainActivity,
                            "پرینت موفقیت‌آمیز بود",
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        Toast.makeText(
                            this@MainActivity,
                            "خطا در پرینت کردن فایل",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    Toast.makeText(
                        this@MainActivity,
                        "پرینتر متصل نیست. لطفا USB OTG را چک کنید",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (e: Exception) {
                Toast.makeText(
                    this@MainActivity,
                    "خطا: ${e.message}",
                    Toast.LENGTH_SHORT
                ).show()
            } finally {
                binding.progressBar.visibility = android.widget.ProgressBar.GONE
                binding.btnPrint.isEnabled = true
            }
        }
    }

    private fun updateFileInfo() {
        binding.tvFileName.text = "فایل انتخابی: $selectedFileName"
        binding.tvFileName.visibility = android.widget.TextView.VISIBLE
        binding.btnPrint.isEnabled = true
    }

    private fun clearSelection() {
        selectedFileUri = null
        selectedFileName = ""
        binding.tvFileName.text = ""
        binding.tvFileName.visibility = android.widget.TextView.GONE
        binding.btnPrint.isEnabled = false
    }

    private fun getFileName(uri: Uri): String {
        var result = ""
        if (uri.scheme == "content") {
            val cursor = contentResolver.query(uri, null, null, null, null)
            cursor?.use {
                if (it.moveToFirst()) {
                    result = it.getString(it.getColumnIndex(OpenableColumns.DISPLAY_NAME))
                }
            }
        } else if (uri.scheme == "file") {
            result = File(uri.path!!).name
        }
        return result
    }

    private fun hasPermissions(): Boolean {
        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            listOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            )
        } else {
            listOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
        }

        return permissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestPermissions() {
        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            )
        } else {
            arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
        }
        permissionsLauncher.launch(permissions)
    }

    private fun checkPermissions() {
        if (!hasPermissions()) {
            requestPermissions()
        }
    }
}
