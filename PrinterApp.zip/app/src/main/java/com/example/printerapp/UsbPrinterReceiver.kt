package com.example.printerapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.hardware.usb.UsbManager
import android.util.Log

class UsbPrinterReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent != null && context != null) {
            when (intent.action) {
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> {
                    Log.d("UsbPrinterReceiver", "پرینتر متصل شد")
                }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    Log.d("UsbPrinterReceiver", "پرینتر جدا شد")
                }
            }
        }
    }
}
