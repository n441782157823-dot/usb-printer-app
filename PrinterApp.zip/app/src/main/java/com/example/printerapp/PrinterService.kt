package com.example.printerapp

import android.content.Context
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream

class PrinterService(private val context: Context) {

    private val usbManager: UsbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager

    suspend fun printFile(fileUri: Uri, fileName: String): Boolean = withContext(Dispatchers.Default) {
        try {
            val fileExtension = fileName.substringAfterLast(".", "").lowercase()
            
            return@withContext when {
                fileExtension in listOf("pdf", "doc", "docx", "txt", "jpg", "jpeg", "png") -> {
                    sendFileToPrinter(fileUri, fileName)
                }
                else -> {
                    Log.e("PrinterService", "فرمت فایل پشتیبانی نشده: $fileExtension")
                    false
                }
            }
        } catch (e: Exception) {
            Log.e("PrinterService", "خطا در پرینت: ${e.message}")
            false
        }
    }

    fun isPrinterConnected(): Boolean {
        val deviceList = usbManager.deviceList
        return deviceList.isNotEmpty() && isPrinterDevice(deviceList)
    }

    private fun isPrinterDevice(deviceList: Map<String, UsbDevice>): Boolean {
        for ((_, device) in deviceList) {
            if (device.deviceClass == 7 || device.deviceClass == 0 || device.deviceName.contains("lp", ignoreCase = true)) {
                Log.d("PrinterService", "پرینتر یافت شد: ${device.deviceName}")
                return true
            }
        }
        return false
    }

    private suspend fun sendFileToPrinter(fileUri: Uri, fileName: String): Boolean = withContext(Dispatchers.Default) {
        try {
            val inputStream: InputStream? = context.contentResolver.openInputStream(fileUri)
            inputStream?.use { stream ->
                val fileData = stream.readBytes()
                return@withContext executeUSBPrint(fileData, fileName)
            }
            return@withContext false
        } catch (e: Exception) {
            Log.e("PrinterService", "خطا در ارسال فایل: ${e.message}")
            false
        }
    }

    private fun executeUSBPrint(data: ByteArray, fileName: String): Boolean {
        try {
            // راه‌اندازی USB رابط برای دستگاه پرینتر
            val device = findPrinterDevice()
            if (device != null) {
                Log.d("PrinterService", "شروع پرینت: $fileName")
                
                // ساخت اتصال USB
                val connection = usbManager.openDevice(device)
                if (connection != null) {
                    // ارسال داده‌ها به پرینتر
                    val endpoint = device.getInterface(0).getEndpoint(0)
                    connection.bulkTransfer(endpoint, data, data.size, 5000)
                    
                    connection.close()
                    Log.d("PrinterService", "پرینت موفق انجام شد")
                    return true
                }
            }
            return false
        } catch (e: Exception) {
            Log.e("PrinterService", "خطا در executeUSBPrint: ${e.message}")
            return false
        }
    }

    private fun findPrinterDevice(): UsbDevice? {
        val deviceList = usbManager.deviceList
        for ((_, device) in deviceList) {
            if (device.deviceClass == 7 || device.deviceClass == 0 || 
                device.deviceName.contains("lp", ignoreCase = true)) {
                return device
            }
        }
        return null
    }
}
